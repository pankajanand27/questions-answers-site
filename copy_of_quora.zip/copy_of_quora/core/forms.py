from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Question, Response


class RegisterUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']


class NewQuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['title', 'description']


class NewResponseForm(forms.ModelForm):
    class Meta:
        model = Response
        fields = ['description']


class NewReplyForm(forms.ModelForm):
    class Meta:
        model = Response
        fields = ['description']
