from django.contrib import auth
from django.contrib.auth import views as auth
from django.urls import path
from . import views
from .views import SignUpView, IndexView

urlpatterns = [
    path('', IndexView.as_view(), name='index'),
    path('signup/', SignUpView.as_view(), name='register'),
    path('login/', views.Login, name='login'),
    # path('logout', views.logoutPage, name='logout'),
    path('logout/', auth.LogoutView.as_view(template_name='homepage.html'), name='logout'),
    path('new-question', views.newQuestionPage, name='new-question'),
    path('question/<int:id>', views.questionPage, name='question'),
    path('reply', views.replyPage, name='reply')
]